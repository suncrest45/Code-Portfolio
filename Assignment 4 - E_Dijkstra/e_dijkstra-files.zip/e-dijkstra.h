#ifndef E_DIJKSTRA_H
#define E_DIJKSTRA_H
bool e_dijkstra( char const *, int ); // input file, range
#endif
