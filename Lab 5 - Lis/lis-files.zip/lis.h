#ifndef LIS_H
#define LIS_H
#include <vector>
std::vector<unsigned> longest_increasing_subsequence( std::vector<int> const& sequence );
#endif
