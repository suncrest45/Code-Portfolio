#ifndef MERGESORT_H
#define MERGESORT_H
void mergesort(int* a, unsigned p, unsigned r);
#endif

