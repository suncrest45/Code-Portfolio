#ifndef PERM_LEXICOGRAPHICAL_H
#define PERM_LEXICOGRAPHICAL_H
#include <vector>

bool nextPermLexicographical (std::vector<int> & p);

#endif
