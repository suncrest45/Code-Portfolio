#ifndef OVERLAP_H
#define OVERLAP_H
#include <map>
std::map<int,int> overlap( char const * filename );
#endif
